export interface FileWithPreview extends File {
  preview: string;
}

